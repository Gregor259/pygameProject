import pygame
import random

pygame.init()
pygame.display.set_caption("Crazy Mouse")
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))

lovka_imag = [pygame.image.load('lovushka.png'), pygame.image.load('kot.png'), pygame.image.load('kzmey.png')]
lovka_options = [69, 438, 50, 450, 50, 445]

mous_imag = [pygame.image.load('mouse0.png'), pygame.image.load('mouse1.png'), pygame.image.load('mouse2.png'), pygame.image.load('mouse3.png'), pygame.image.load('mouse4.png')]
img_counter = 5

class Lovka:
    def __init__(self, x, y, width, image, speed):
        self.x = x
        self.y = y
        self.width = width
        self.image = image
        self.speed = speed

    def dvig(self):
        if self.x >= -self.width:
            screen.blit(self.image, (self.x, self.y))
            # pygame.draw.rect(screen, (224, 121, 31), (self.x, self.y, self.width, self.height))
            self.x -= self.speed
            return True
        else:
            #self.x = screen_width + 100 + random.randrange(-80, 60)
            return False

    def vyvod_self(self, rasst, y, width, image):
        self.x = rasst
        self.y = y
        self.width = width
        self.image = image
        screen.blit(self.image, (self.x, self.y))


mouse_width = 60
mouse_height = 100
mouse_x = screen_width // 3
mouse_y = screen_height - mouse_height - 100
mouselovka_width = 20
mouselovka_height = 70
mouselovka_x = screen_width - 50
mouselovka_y = screen_height - mouselovka_height - 100
clock = pygame.time.Clock()
mouse_jump = False
jump_chet = 30


def run():
    global mouse_jump, mouse_x, mouse_y, mouselovka_width, mouselovka_height
    game = True
    mouselovka_mas = []
    creating_mouselovka(mouselovka_mas)
    land = pygame.image.load('Land.jpg')

    while game:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
        keys = pygame.key.get_pressed()
        if keys[pygame.K_SPACE]:
            mouse_jump = True
        if mouse_jump:
            jumping()
        screen.blit(land, (0, 0))
        drawing(mouselovka_mas)

        #pygame.draw.rect(screen, (247, 240, 22), (mouse_x, mouse_y, mouse_width, mouse_height))
        draw_mouse()
        pygame.display.update()
        clock.tick(50)


def jumping():
    global mouse_y, jump_chet, mouse_jump
    if jump_chet >= -30:
        mouse_y -= jump_chet / 2.5
        jump_chet -= 1
    else:
        jump_chet = 30
        mouse_jump = False


def creating_mouselovka(array):
    choice = random.randrange(0, 3)
    img = lovka_imag[choice]
    width = lovka_options[choice * 2]
    height = lovka_options[choice * 2 + 1]
    array.append(Lovka(screen_width + 20, height, width, img, 4))

    choice = random.randrange(0, 3)
    img = lovka_imag[choice]
    width = lovka_options[choice * 2]
    height = lovka_options[choice * 2 + 1]
    array.append(Lovka(screen_width + 300, height, width, img, 4))

    choice = random.randrange(0, 3)
    img = lovka_imag[choice]
    width = lovka_options[choice * 2]
    height = lovka_options[choice * 2 + 1]
    array.append(Lovka(screen_width + 600, height, width, img, 4))



def rasstf(array):
    maxis = max(array[0].x, array[1].x, array[2].x)
    if maxis < screen_width:
        rasst = screen_width
        if rasst - maxis < 50:
            rasst += 150
        else:
            rasst = maxis
        choice = random.randrange(0, 5)
        if choice == 0:
            rasst += random.randrange(10, 15)
        else:
            rasst += random.randrange(200, 350)
        return rasst


def drawing(array):
    for lovka in array:
        checking = lovka.dvig()
        if not checking:
            rasst = rasstf(array)

            choice = random.randrange(0, 3)
            img = lovka_imag[choice]
            width = lovka_options[choice * 2]
            height = lovka_options[choice * 2 + 1]

            lovka.vyvod_self(rasst, height, width, img)

def draw_mouse():
    global img_counter
    if img_counter == 25:
        img_counter = 0

    screen.blit(mous_imag[img_counter // 5], (mouse_x, mouse_y))
    img_counter +=1



run()
